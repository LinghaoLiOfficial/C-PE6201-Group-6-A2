# Group 6 - Case Design Pack (English v1.1)

1. Read Group6_ProblemA_Case_Design_Request_EN.pdf for the requirements and your ID block.
2. Read the three worked examples on pages 5-7. Exact instructor claim/label rows
   are in reference_examples/. They are references, not your original cases.
3. Copy templates/, rename NAME to your own name, and fill five new claims,
   five independent labels and a design note. Four cases should be ACT and the
   fifth your assigned negative. Submit the three files to LI LINGHAO.

The 15 instructor cases remain in the final set unchanged. Your five are additions.
Reference JSON files must not be inserted again into EXTRA_CLAIMS or the answer key.

The templates contain empty JSON containers, not completed cases.
Use the instructor's materials/A2_reference_data/data_A supporting tables when
checking member, policy, document and authorisation references. Source filenames
and page citations are in the PDF. Submission timing is communicated separately.
